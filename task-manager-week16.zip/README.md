# Task Manager (Spring Boot + React)

This is a minimal full‑stack Task Manager app ready for **Week 16**: Deployment & DevOps Basics.

## Backend (Spring Boot)
- CRUD Tasks
- JPA + Postgres (Heroku) with fallback to in‑memory H2 locally
- Port: `${PORT:8080}`
- Endpoints under `/api/tasks`

### Run locally
```bash
cd backend
./mvnw spring-boot:run  # if wrapper exists
# or
mvn clean package -DskipTests
java -jar target/*.jar
```

### Deploy to Heroku (manual)
```bash
heroku login
heroku create your-taskmanager-backend
heroku addons:create heroku-postgresql:hobby-dev --app your-taskmanager-backend
heroku config --app your-taskmanager-backend
git init && git add . && git commit -m "init"
git push https://heroku:$HEROKU_API_KEY@git.heroku.com/your-taskmanager-backend.git main
```

## Frontend (React + Vite)
- Uses env `REACT_APP_API_URL` in `.env.production` to call backend

### Run locally
```bash
cd frontend
npm install
npm run dev
```

## CI/CD
Add the following GitHub secrets for the repo:
- `HEROKU_API_KEY`
- `VERCEL_TOKEN`, `VERCEL_ORG_ID`, `VERCEL_PROJECT_ID`
