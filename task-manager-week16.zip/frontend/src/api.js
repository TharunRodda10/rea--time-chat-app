import axios from 'axios';

const API = import.meta.env.VITE_API_URL || import.meta.env.RENDER_EXTERNAL_URL || import.meta.env.VITE_BACKEND_URL || (typeof process !== 'undefined' ? process.env.REACT_APP_API_URL : '');

// Fallback for CRA-style env
const BASE = API || (import.meta.env ? import.meta.env.REACT_APP_API_URL : '') || '';

export const listTasks = () => axios.get(`${BASE}/api/tasks`);
export const addTask = (task) => axios.post(`${BASE}/api/tasks`, task);
export const updateTask = (id, task) => axios.put(`${BASE}/api/tasks/${id}`, task);
export const deleteTask = (id) => axios.delete(`${BASE}/api/tasks/${id}`);
