import React, { useEffect, useState } from 'react';
import { listTasks, addTask, updateTask, deleteTask } from './api.js';

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');

  const refresh = async () => {
    const { data } = await listTasks();
    setTasks(data);
  };

  useEffect(() => { refresh(); }, []);

  const create = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    await addTask({ title });
    setTitle('');
    refresh();
  };

  const toggle = async (t) => {
    await updateTask(t.id, { ...t, completed: !t.completed });
    refresh();
  };

  const remove = async (id) => {
    await deleteTask(id);
    refresh();
  };

  return (
    <div style={{ maxWidth: 720, margin: '40px auto', fontFamily: 'system-ui, Arial', padding: 16 }}>
      <h1>Task Manager</h1>
      <form onSubmit={create} style={{ marginBottom: 16 }}>
        <input
          placeholder="Add a new task..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          style={{ padding: 8, width: '70%' }}
        />
        <button style={{ padding: 8, marginLeft: 8 }} type="submit">Add</button>
      </form>

      <ul style={{ listStyle: 'none', padding: 0 }}>
        {tasks.map(t => (
          <li key={t.id} style={{ display: 'flex', alignItems: 'center', padding: 8, borderBottom: '1px solid #ddd' }}>
            <input type="checkbox" checked={t.completed} onChange={() => toggle(t)} />
            <span style={{ marginLeft: 8, flex: 1, textDecoration: t.completed ? 'line-through' : 'none' }}>{t.title}</span>
            <button onClick={() => remove(t.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}
