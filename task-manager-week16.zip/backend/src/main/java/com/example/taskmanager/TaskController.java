package com.example.taskmanager;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@RestController
@RequestMapping("/api/tasks")
@CrossOrigin(origins = "*") // adjust in production if needed
public class TaskController {

    @Autowired
    private TaskRepository repo;

    @GetMapping
    public List<Task> all() {
        return repo.findAll();
    }

    @PostMapping
    public ResponseEntity<Task> create(@RequestBody Task task) {
        if (task.getTitle() == null || task.getTitle().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Title is required");
        }
        Task saved = repo.save(task);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PutMapping("/{id}")
    public Task update(@PathVariable Long id, @RequestBody Task update) {
        return repo.findById(id).map(t -> {
            if (update.getTitle() != null) t.setTitle(update.getTitle());
            t.setCompleted(update.isCompleted());
            return repo.save(t);
        }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found"));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Task not found");
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
